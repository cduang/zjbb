#!/system/bin/sh

# ==========================================
# 开启纯脚本模式，阻止 KSU 生成模块文件夹
# ==========================================
SKIPUNZIP=1

TMP_DIR="/data/local/tmp"

ui_print " "
ui_print " █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█ "
ui_print " █     天翼云机全自动部署 (即时执行)     █ "
ui_print " █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█ "
ui_print " "

ui_print "[*] 正在接管系统底层权限..."
ui_print " "

# ==========================================
# 【函数】：实时下载与安装 (带 UI 打印)
# ==========================================
download_and_install() {
    local app_name=$1
    local dest_apk="$TMP_DIR/$2"
    shift 2 
    local success=0

    ui_print ">>> 开始处理: $app_name"
    ui_print "- 正在连接镜像加速节点 (请耐心等待)..."

    for url in "$@"; do
        # 静默下载，但设置超时避免卡死
        curl -k -L -f -s --connect-timeout 10 -o "$dest_apk" "$url"
        if [ $? -eq 0 ] && [ -s "$dest_apk" ]; then
            success=1
            ui_print "- [成功] 下载完成，正在安装..."
            break
        fi
        rm -f "$dest_apk"
    done

    if [ $success -eq 1 ]; then
        pm install -r "$dest_apk" > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            ui_print "- [成功] 安装完毕！"
        else
            ui_print "- [失败] 安装过程出错！"
        fi
        rm -f "$dest_apk"
    else
        ui_print "- [错误] 所有加速节点均下载失败！"
    fi
    ui_print " "
}

# ==========================================
# 1. 实时下载与安装
# ==========================================
ui_print "============ 阶段一：装机 ============"

download_and_install "Via浏览器" "via.apk" "https://res.viayoo.com/v1/via-release-cn.apk"

download_and_install "困鱼 (AutoJS)" "kunyu.apk" \
    "https://v4.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk" \
    "https://gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk" \
    "https://v6.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk" \
    "https://cdn.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk"

download_and_install "MT管理器" "mt.apk" \
    "https://v4.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk" \
    "https://gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk" \
    "https://v6.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk" \
    "https://cdn.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk"

# ==========================================
# 2. 自动授予高级权限
# ==========================================
ui_print "============ 阶段二：授权 ============"
if pm list packages | grep -q "bin.mt.plus"; then
    ui_print "- 正在为 MT管理器 授予读写权限..."
    pm grant "bin.mt.plus" android.permission.READ_EXTERNAL_STORAGE > /dev/null 2>&1
    pm grant "bin.mt.plus" android.permission.WRITE_EXTERNAL_STORAGE > /dev/null 2>&1
    appops set "bin.mt.plus" MANAGE_EXTERNAL_STORAGE allow
    ui_print "  -> 授权成功"
fi

if pm list packages | grep -q "org.autojs.autojspro"; then
    ui_print "- 正在为 困鱼 授予悬浮窗权限..."
    appops set "org.autojs.autojspro" SYSTEM_ALERT_WINDOW allow
    ui_print "  -> 授权成功"
fi
ui_print " "

# ==========================================
# 3. 冻结系统组件
# ==========================================
ui_print "============ 阶段三：冻结 ============"
FREEZE_APPS="
com.google.android.gsf              # 谷歌服务框架
com.google.android.gms              # 谷歌Play服务
com.android.vending                 # 谷歌Play商店
com.ctg.itrdc.mobilemanager         # 天翼云手机管家
"
echo "$FREEZE_APPS" | while read -r line; do
    app=$(echo "$line" | awk '{print $1}')
    if [ -n "$app" ] && [ "${app:0:1}" != "#" ]; then
        if pm disable-user --user 0 "$app" > /dev/null 2>&1; then
            ui_print "- [已冻结] $app"
        fi
    fi
done
ui_print " "

# ==========================================
# 4. 卸载系统组件
# ==========================================
ui_print "============ 阶段四：卸载 ============"
UNINSTALL_APPS="
com.telecom.video                   # 天翼视频/视讯
com.gm.cloud.travel                 # 天翼出行
cn.egame.terminal.cloud5g           # 天翼云游戏终端
com.ctg.itrdc.cloudphone.help       # 天翼云手机帮助
com.corp21cn.mail189                # 189邮箱
com.qihoo.contents                  # 360相关
com.qihoo.appstore                  # 360手机助手
com.qihoo.pluginbox.wenku           # 360文库
com.benfuip.client                  # 本富IP代理
com.hunantv.imgo.activity           # 芒果TV
com.cn21.corp.cloud                 # 天翼企业云
com.cn21.ecloud                     # 天翼云盘
com.tencent.android.qqdownloader    # 腾讯应用宝
"
echo "$UNINSTALL_APPS" | while read -r line; do
    app=$(echo "$line" | awk '{print $1}')
    if [ -n "$app" ] && [ "${app:0:1}" != "#" ]; then
        if pm uninstall -k --user 0 "$app" > /dev/null 2>&1; then
            ui_print "- [已卸载] $app"
        fi
    fi
done

ui_print " "
ui_print "========================================="
ui_print "  所有任务执行完毕！"
ui_print "  你可以直接退出 KSU 界面，无需重启！"
ui_print "  记得去 KSU 勾选 MT管理器 和 困鱼 的 Root 权限。"
ui_print "========================================="