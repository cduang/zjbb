#!/system/bin/sh

# 获取当前模块路径
MODDIR=${0%/*}
# 临时下载目录
TMP_DIR="/data/local/tmp"

# ==========================================
# 【关键阶段 1】：等待系统环境就绪
# ==========================================
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# 系统启动后额外等 15 秒，确保安卓包管理器 (PM) 完全启动
sleep 15

# ==========================================
# 【核心函数】：支持备用链接的下载与安装
# ==========================================
download_and_install() {
    local app_name=$1
    local dest_apk="$TMP_DIR/$2"
    shift 2 
    local success=0

    for url in "$@"; do
        curl -k -L -f --connect-timeout 10 -o "$dest_apk" "$url"
        if [ $? -eq 0 ] && [ -s "$dest_apk" ]; then
            success=1
            break
        fi
        rm -f "$dest_apk"
    done

    if [ $success -eq 1 ]; then
        pm install -r "$dest_apk" > /dev/null 2>&1
        rm -f "$dest_apk"
    fi
}

# ==========================================
# 【执行阶段 2】：自动化下载与安装
# ==========================================

# 1. Via 浏览器
download_and_install "Via浏览器" "via.apk" "https://res.viayoo.com/v1/via-release-cn.apk"

# 2. 困鱼 (AutoJS.fake.latest.apk) 
download_and_install "困鱼" "kunyu.apk" \
    "https://v4.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk" \
    "https://gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk" \
    "https://v6.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk" \
    "https://cdn.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/AutoJS.fake.latest.apk"

# 3. MT管理器 (MT2.26.4.apk)
download_and_install "MT管理器" "mt.apk" \
    "https://v4.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk" \
    "https://gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk" \
    "https://v6.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk" \
    "https://cdn.gh-proxy.org/https://github.com/cduang/zjbb/raw/refs/heads/main/MT2.26.4.apk"


# ==========================================
# 【执行阶段 3】：冻结无用系统组件
# ==========================================
# 格式: 包名 # 注释说明
FREEZE_APPS="
com.google.android.gsf              # 谷歌服务框架
com.google.android.gms              # 谷歌Play服务
com.android.vending                 # 谷歌Play商店
com.ctg.itrdc.mobilemanager         # 天翼云手机自带管家 (卸载易报错，冻结最稳)
"

# 逐行读取，利用 awk 提取第一列包名，自动忽略中文注释
echo "$FREEZE_APPS" | while read -r line; do
    app=$(echo "$line" | awk '{print $1}')
    if [ -n "$app" ] && [ "${app:0:1}" != "#" ]; then
        pm disable-user --user 0 "$app" > /dev/null 2>&1
    fi
done

# ==========================================
# 【执行阶段 4】：卸载无用系统组件
# ==========================================
UNINSTALL_APPS="
com.telecom.video                   # 天翼视频/视讯
com.gm.cloud.travel                 # 天翼出行
cn.egame.terminal.cloud5g           # 天翼云游戏终端
com.ctg.itrdc.cloudphone.help       # 天翼云手机帮助
com.corp21cn.mail189                # 189邮箱
com.qihoo.contents                  # 360相关内容组件
com.qihoo.appstore                  # 360手机助手/应用市场
com.qihoo.pluginbox.wenku           # 360文库插件
com.benfuip.client                  # 本富IP代理客户端(预装推广软件)
com.hunantv.imgo.activity           # 芒果TV
com.cn21.corp.cloud                 # 天翼企业云
com.cn21.ecloud                     # 天翼云盘
com.tencent.android.qqdownloader    # 腾讯应用宝
"

echo "$UNINSTALL_APPS" | while read -r line; do
    app=$(echo "$line" | awk '{print $1}')
    if [ -n "$app" ] && [ "${app:0:1}" != "#" ]; then
        pm uninstall -k --user 0 "$app" > /dev/null 2>&1
    fi
done

# ==========================================
# 【收尾阶段 5】：模块阅后即焚
# ==========================================
# 自动创建 disable 文件，KSU 管理器中此模块将在下次开机被自动停用
touch "$MODDIR/disable"